﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiClasses
{
    public  class Endpoints
    {
        public static readonly string BASE_URL = "https://localhost:5099";
        public static readonly string GetAllItem = "/api/catalog-items";
        public static readonly string GetItemById = "/api/catalog-items/{catalogItemId}";
        public static readonly string CreateItem = "/api/catalog-items";
        public static readonly string UpdateItem = "/api/catalog-items";
        public static readonly string DeleteItem = "/api/catalog-items/{catalogItemId}";
    }
}
