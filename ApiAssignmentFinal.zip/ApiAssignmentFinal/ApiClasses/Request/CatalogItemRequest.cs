﻿using System.Linq;

public class CatalogItemRequest
{
    public int catalogBrandId { get; set; }
    public int catalogTypeId { get; set; }
    public string description { get; set; }
    public string name { get; set; }
    public string pictureUri { get; set; }
    public string pictureBase64 { get; set; }
    public string pictureName { get; set; }
    public decimal price { get; set; }


}
