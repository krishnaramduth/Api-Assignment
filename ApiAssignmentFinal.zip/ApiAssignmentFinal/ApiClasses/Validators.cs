﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp.Serializers;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using NUnit;
using NUnit.Framework;
using ApiClasses.Request;
using System.Runtime.InteropServices;
using System.IO;
using NUnit;
using NUnit.Framework;
using ApiClasses.Response;
using TechTalk.SpecFlow;
namespace ApiClasses
{
    public class Validators
    {
        private CatalogItemss catalogItem;
        public void validateRestponseJson(RestResponse restResponse)
        {

            if (restResponse.Content == null)
            {
                Assert.Fail();
            }
            else
            {
                JObject jsonObject = JObject.Parse(restResponse.Content);

            }

        }

        public bool countItemsgg(RestResponse restResponse)
        {
            int count = 0;
            JObject jsonObject = JObject.Parse(restResponse.Content);
            if (jsonObject == null)
            {
                Assert.Fail();
            }
            else
            {
                count = jsonObject["catalogItems"].Count();
                if (count > 0)
                {
                    return true;
                }
            }
            return false;
        }

        public bool CheckIfContainItem(RestResponse restResponse)
        {

            try
            {
           
                //JObject jsonObject = JObject.Parse(restResponse.Content);
                var catalogItems = JsonConvert.DeserializeObject<DataModel>(restResponse.Content);

                foreach (var catalogItem in catalogItems.catalogItems)
                {
                    if (catalogItem.description != null && catalogItem.description.ToString() != "")
                    { 
                        return true;
                    }

                }
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            
            return false;

        }

        public bool checkIfItemIsCreated(RestResponse restResponse)
        {
            try
            {
                JObject jsonObject = JObject.Parse(restResponse.Content);
                var catalogItems = JsonConvert.DeserializeObject<PostResponse>(restResponse.Content);

                if(catalogItems.catalogItem.description !="" || catalogItems.catalogItem.description != null)
                {
                    
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }

            return false;
        }


        public bool GetItembyid(RestResponse restResponse , int id)
        {

            try
            {
                int count = 0;
                JObject jsonObject = JObject.Parse(restResponse.Content);
                var catalogItems = JsonConvert.DeserializeObject<GetItemByIdRequest>(restResponse.Content);

             if (catalogItems.catalogItem.id == id)
                {
                    Assert.AreEqual(catalogItems.catalogItem.id, id);
                    return true;
                }
                else
                {
                    Assert.AreEqual(catalogItems.catalogItem.id, id);
                    return false;
                }
            }

            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void VerifyColumns(TechTalk.SpecFlow.Table table)
        {

            string jsonFilePath = "column_names.json";

            string jsonText = File.ReadAllText(jsonFilePath);

            // Deserialize the JSON content into a ColumnNamesConfig object
            var columnNamesConfig = JsonConvert.DeserializeObject<ColumnNamesConfig>(jsonText);

            // Get the list of expected column names
            List<string> expectedColumns = columnNamesConfig.ExpectedColumns;
            
            // Check if the DataTable contains all the expected columns
            bool allColumnsExist = expectedColumns.All(columnName => table.ContainsColumn(columnName));

            // Perform your assertions
            Assert.IsTrue(allColumnsExist, "The DataTable does not contain all expected columns.");
        } 

    }


   

}
