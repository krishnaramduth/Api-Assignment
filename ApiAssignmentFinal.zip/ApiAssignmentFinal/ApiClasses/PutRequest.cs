﻿using ApiClasses.Request;
using ApiClasses.Response;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using TechTalk.SpecFlow;
namespace ApiClasses
{
    public class PutRequest
    {
        public RestResponse testPutEnpoint(CatalogItemUpdateRequest catUpdate)
        {
            try
            {
                string baseUrl = Endpoints.BASE_URL;
                var client = new RestClient(baseUrl);

                var request = new RestRequest(Endpoints.UpdateItem, Method.Put);
                request.AddHeader("Authorization", "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFkbWluQG1pY3Jvc29mdC5jb20iLCJyb2xlIjoiQWRtaW5pc3RyYXRvcnMiLCJuYmYiOjE2OTQ3NTg4MjYsImV4cCI6MTY5NTM2MzYyNiwiaWF0IjoxNjk0NzU4ODI2fQ.DPX7SVFiwINse7zPDyb5VodL_ZvuKaL5ZQnebKLHAXQ");
                request.AddJsonBody(catUpdate);

                RestResponse response = client.Execute(request);
                switch ((int)response.StatusCode)
                {
                    case (int)HttpStatusCode.OK:
                        Assert.AreEqual((int)response.StatusCode, (int)HttpStatusCode.OK);
                        return response;
                        break;

                        return response;
                        break;
                    default:
                    case (int)HttpStatusCode.NonAuthoritativeInformation:
                        Console.WriteLine("Message   " + response.StatusCode);

                        Assert.Fail();
                        Assert.Fail();
                        Console.WriteLine("Message " + response.StatusCode);
                        break;

                }
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


     
        public void IsWellUpdated(RestResponse response, TechTalk.SpecFlow.Table table)
        {

            var catalogItems = JsonConvert.DeserializeObject<PutResponse>(response.Content);

            var expectedCatalogItem = new PutResponse.Catalogitem
            {
                id = int.Parse(table.Rows[0]["Id"]),
                name = table.Rows[0]["name"],
                description = table.Rows[0]["description"],
                price = float.Parse(table.Rows[0]["price"]),
                pictureUri = table.Rows[0]["pictureUri"],
                catalogTypeId = int.Parse(table.Rows[0]["catalogTypeId"]),
                catalogBrandId = int.Parse(table.Rows[0]["catalogBrandId"])
            };
            Assert.AreEqual(expectedCatalogItem, catalogItems.catalogItem);

            /*    |  Id| catalogBrandId | catalogTypeId | description | name     | pictureBase64 | pictureUri  | pictureName  | price  |*/

        }
    }
}

