﻿using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;


namespace ApiClasses
{
    public  class PostRequest
    {
        public RestResponse testPostEnpoint(CatalogItemRequest cat )
        {
            try
            {
                string baseUrl = Endpoints.BASE_URL;
                var client = new RestClient(baseUrl);
               
                var request = new RestRequest(Endpoints.CreateItem, Method.Post);
                request.AddHeader("Authorization", "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFkbWluQG1pY3Jvc29mdC5jb20iLCJyb2xlIjoiQWRtaW5pc3RyYXRvcnMiLCJuYmYiOjE2OTQ3NDYxOTUsImV4cCI6MTY5NTM1MDk5NSwiaWF0IjoxNjk0NzQ2MTk1fQ.gYUyhgCWESmXkIiS5zvYIEkY04KYP2zT13nWvIskSVw");
                request.AddJsonBody(cat);

                RestResponse response = client.Execute(request);
                switch((int)response.StatusCode)
                {
                    case (int)HttpStatusCode.Created:
                        return response;
                        break;
          
                    case (int)HttpStatusCode.NonAuthoritativeInformation:
                        Console.WriteLine("Message   " + response.StatusCode);

                        Assert.Fail();
                        return response;
                        break;
                    default:
                        Assert.Fail();
                        Console.WriteLine("Message "+response.StatusCode);
                        break;
                        
                }
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
          

        }

        
    }
}




