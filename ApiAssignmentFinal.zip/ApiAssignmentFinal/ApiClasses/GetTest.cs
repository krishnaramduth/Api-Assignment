﻿using ApiClasses;
using ApiClasses.Request;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMethods
{
    public  class GetTest
    {


       
        public RestResponse testGetAllEnpoint()
        {
            
            string baseUrl = Endpoints.BASE_URL;
            string endpoint =Endpoints.GetAllItem;

           
            var client = new RestClient(baseUrl);

            
            var request = new RestRequest(endpoint, Method.Get);

         
            RestResponse response = client.Execute(request);

           
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Request was successful.");
                Console.WriteLine("Response content:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Request failed with status code: " + response.StatusCode);
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }
            return response;
        }


        public RestResponse TestGetEnpoint(int catalogItemId)
        {

            string baseUrl = Endpoints.BASE_URL;
        
            var client = new RestClient(baseUrl);

  
            var request = new RestRequest(Endpoints.GetItemById, Method.Get);
            request.AddUrlSegment("catalogItemId", catalogItemId.ToString());

           
            RestResponse response = client.Execute(request);

            
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Request was successful.");
                Console.WriteLine("Response content:");
                Console.WriteLine(response.Content);
                return response;

            }
            else
            {
                Console.WriteLine("Request failed with status code: " + response.StatusCode);
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }
            return response;
        }
    }
}



