﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

// Define a class to represent the JSON structure
public class ColumnNamesConfig
{
    public List<string> ExpectedColumns { get; set; }
}