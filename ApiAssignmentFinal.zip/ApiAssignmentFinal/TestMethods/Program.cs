﻿
using System;
using RestSharp;
using TestMethods;

public class Program
{
    public static void Main(String[] arg)
    {
       DeleteTest test = new DeleteTest();
        test.testDeleteEndpoint();
    }
}