﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMethods
{
    internal class PostTests
    {

        public void testPostEnpoint()
        {
            // Define the base URL
            string baseUrl = "https://localhost:5099";

            // Create a RestClient instance
            var client = new RestClient(baseUrl);

            // Create a CatalogItemRequest object with the data you want to send
            var requestPayload = new CatalogItemRequest
            {
                catalogBrandId = 5,
                catalogTypeId = 2,
                description = "string",
                name = "string",
                pictureUri = "string",
                pictureBase64 = "string",
                pictureName = "string",
                price = 89
            };

            // Create a RestRequest for the POST request
            var request = new RestRequest("/api/catalog-items", Method.Post);
            request.AddHeader("Authorization", "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFkbWluQG1pY3Jvc29mdC5jb20iLCJyb2xlIjoiQWRtaW5pc3RyYXRvcnMiLCJuYmYiOjE2OTQ1NDE4MDYsImV4cCI6MTY5NTE0NjYwNiwiaWF0IjoxNjk0NTQxODA2fQ.LfqmyXGiqFd66HXSS7DPJ5Vhkp3NGTLodPF4IpNEegY");
            request.AddJsonBody(requestPayload);

            // Execute the request and get the response
            RestResponse response = client.Execute(request);

            // Check if the response is successful (HTTP status code 2xx)
            if ((int)response.StatusCode >= 200 && (int)response.StatusCode < 300)
            {
                Console.WriteLine("Request was successful.");
                Console.WriteLine("Response content:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Request failed with status code: " + response.StatusCode);
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }

        }
    }
}
