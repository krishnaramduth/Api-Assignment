﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMethods
{
    internal class GetTest
    {

        public void testGetAllEnpoint()
        {
            // Define the base URL and the endpoint
            string baseUrl = "https://localhost:5099";
            string endpoint = "/api/catalog-items";

            // Create a RestClient instance
            var client = new RestClient(baseUrl);

            // Create a RestRequest for the GET request
            var request = new RestRequest(endpoint, Method.Get);

            // Execute the request and get the response
            RestResponse response = client.Execute(request);

            // Check if the response is successful (HTTP status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Request was successful.");
                Console.WriteLine("Response content:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Request failed with status code: " + response.StatusCode);
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }
        }


        public void testGetEnpoint()
        {
            // Define the base URL
            string baseUrl = "https://localhost:5099";

            // Input catalogItemId (replace with your actual value)
            int catalogItemId = 2; // Replace with the actual ID you want to retrieve

            // Create a RestClient instance
            var client = new RestClient(baseUrl);

            // Create a RestRequest for the GET request with a parameter
            var request = new RestRequest("/api/catalog-items/{catalogItemId}", Method.Get);
            request.AddUrlSegment("catalogItemId", catalogItemId.ToString()); // Replace the parameter value

            // Execute the request and get the response
            RestResponse response = client.Execute(request);

            // Check if the response is successful (HTTP status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Request was successful.");
                Console.WriteLine("Response content:");
                Console.WriteLine(response.Content);
            }
            else
            {
                Console.WriteLine("Request failed with status code: " + response.StatusCode);
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }
        }
    }
}



