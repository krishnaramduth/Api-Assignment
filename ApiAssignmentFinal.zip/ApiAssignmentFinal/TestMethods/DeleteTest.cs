﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestMethods
{
    internal class DeleteTest
    {
        public void testDeleteEndpoint() {

            string baseUrl = "https://localhost:5099";
            int catalogItemIdToDelete = 5; // Replace with the actual ID you want to delete

            var client = new RestClient(baseUrl);

            var request = new RestRequest($"/api/catalog-items/{catalogItemIdToDelete}", Method.Delete);
            request.AddHeader("Authorization", "Bearer " + "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImFkbWluQG1pY3Jvc29mdC5jb20iLCJyb2xlIjoiQWRtaW5pc3RyYXRvcnMiLCJuYmYiOjE2OTQ1NDE4MDYsImV4cCI6MTY5NTE0NjYwNiwiaWF0IjoxNjk0NTQxODA2fQ.LfqmyXGiqFd66HXSS7DPJ5Vhkp3NGTLodPF4IpNEegY");

            RestResponse response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                Console.WriteLine($"DELETE request for catalog item with ID {catalogItemIdToDelete} was successful.");
            }
            else
            {
                Console.WriteLine($"DELETE request failed with status code: {response.StatusCode}");
                Console.WriteLine("Error message:");
                Console.WriteLine(response.ErrorMessage);
            }
        }
    }
}
