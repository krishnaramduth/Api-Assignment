using System;
using TechTalk.SpecFlow;

namespace ApiAssignmentFinal.StepDefinitions
{
    [Binding]
    public class DeleteCatalogItemStepDefinitions
    {
        
    }
}
