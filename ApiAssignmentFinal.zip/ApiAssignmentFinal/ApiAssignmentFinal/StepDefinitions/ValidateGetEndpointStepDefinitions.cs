using System;
using TechTalk.SpecFlow;
using RestSharp;
using TestMethods;
using NUnit.Framework;
using ApiClasses;
using Newtonsoft.Json;

namespace ApiAssignmentFinal.StepDefinitions
{
    [Binding]
    public class ValidateGetEndpointStepDefinitions
    {
        private RestResponse response;
        private readonly GetTest test = new GetTest();
        private readonly Validators Validate = new Validators();
        [When(@"I make a GET request to Get endpoint")]
        public void WhenIMakeAGETRequestToGetEndpoint()
        {
            response = test.testGetAllEnpoint();
        }

        [Then(@"the response status code should equal to (.*)")]
        public void ThenTheResponseStatusCodeShouldEqualTo(int p0)
        {
            try {
                Assert.AreEqual((int)response.StatusCode, p0);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        [Then(@"the response content should be a JSON array")]
        public void ThenTheResponseContentShouldBeAJSONArray()
        {
            Validate.validateRestponseJson(response);
        }

        [Then(@"the response should contain a list of catalog items")]
        public void ThenTheResponseShouldContainAListOfCatalogItems()
        {
            Assert.IsTrue(Validate.CheckIfContainItem(response));
        }



       
    }
}
