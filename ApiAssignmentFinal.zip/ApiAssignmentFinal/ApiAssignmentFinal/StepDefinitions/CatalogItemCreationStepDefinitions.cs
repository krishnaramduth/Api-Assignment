using RestSharp;
using System;
using TechTalk.SpecFlow;
using TestMethods;
using ApiClasses;
using System.ComponentModel.DataAnnotations;
using NUnit;
using NUnit.Framework;

namespace ApiAssignmentFinal.StepDefinitions
{
    [Binding]
    public class CatalogItemCreationStepDefinitions
    {

        private CatalogItemRequest catalogItemRequest;
        private RestResponse response;
        private readonly Validators Validate = new Validators();
        private readonly PostRequest test = new PostRequest();
        [When(@"I make a POST request to the post endpoint with the following details:")]
        public void WhenIMakeAPOSTRequestToThePostEndpointWithTheFollowingDetails(Table table)
        {
           
           
               

                catalogItemRequest = new CatalogItemRequest
                {
                    catalogBrandId = int.Parse(table.Rows[0]["catalogBrandId"]),
                    catalogTypeId = int.Parse(table.Rows[0]["catalogTypeId"]),
                    description = table.Rows[0]["description"],
                    name = table.Rows[0]["name"],
                    pictureUri = table.Rows[0]["pictureUri"],
                    pictureBase64 = table.Rows[0]["pictureBase64"],
                    pictureName = table.Rows[0]["pictureName"],
                    price = decimal.Parse(table.Rows[0]["price"])
                };

                response = test.testPostEnpoint(catalogItemRequest);

                if (response.StatusCode == System.Net.HttpStatusCode.Created)

                {
                Assert.AreEqual(response.StatusCode, System.Net.HttpStatusCode.Created);
                    Console.WriteLine("The item has been sucessfull created ");

                }
                else
                {
                Assert.Fail();
                    Console.WriteLine("The item has not been sucessfull created statuscode " + (response.StatusCode).ToString());
                }


            
        }

     
      

       [Then(@"the response statuscode should be  (.*)")]
        public void ThenTheResponseStatusCodeShouldBe(int p0)
        {
            try
            {
                Assert.AreEqual((int)response.StatusCode, p0);
            }
            catch(Exception e)
            {
                Console.WriteLine("Message " +e.ToString());
            }
            
        }


        [Then(@"the response should contain the created catalog item details")]
        public void ThenTheResponseShouldContainTheCreatedCatalogItemDetails()
        {
            Validate.checkIfItemIsCreated(response);
        }

    }
}
