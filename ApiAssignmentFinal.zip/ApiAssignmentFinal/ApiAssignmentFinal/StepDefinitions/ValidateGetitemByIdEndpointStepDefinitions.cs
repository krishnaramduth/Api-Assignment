using System;
using TechTalk.SpecFlow;
using RestSharp;
using TestMethods;
using NUnit.Framework;
using ApiClasses;
using Newtonsoft.Json;

namespace ApiAssignmentFinal.StepDefinitions
{
    [Binding]
    public class ValidateGetitemByIdEndpointStepDefinitions
    {


        private RestResponse response;
        private readonly GetTest test = new GetTest();
        private readonly Validators Validate = new Validators();
        [Given(@"I make a GET request to the Get endpoint with ID ""([^""]*)""")]
        public void GivenIMakeAGETRequestToTheGetEndpointWithID(string p0)
        {
            response= test.TestGetEnpoint(int.Parse(p0));
        }



        [Then(@"the response status code should be (.*)")]
        public void ThenTheResponseStatusCodeShouldBe(int p0)
        {
            try
            {
                Assert.AreEqual((int)response.StatusCode, p0);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }

        [Then(@"the response should contain the catalog item with ID ""([^""]*)""")]
        public void ThenTheResponseShouldContainTheCatalogItemWithID(string p0)
        {
            Assert.IsTrue(Validate.GetItembyid(response, int.Parse(p0)));
        }

    }
}
