using NUnit.Framework.Internal;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using RestSharp;
using ApiClasses;

namespace ApiAssignmentFinal.StepDefinitions
{
    [Binding]
    public class UpdateCatalogItemStepDefinitions
    {
        private CatalogItemUpdateRequest catalogItemRequest;
        private RestResponse response ;
        private readonly PutRequest test = new PutRequest();
        private ScenarioContext _scenarioContext;


        public UpdateCatalogItemStepDefinitions(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }
        [When(@"I make a PUT request to the post endpoint with the following details:")]
        public void WhenIMakeAPUTRequestToThePostEndpointWithTheFollowingDetails(Table table)
        {

            catalogItemRequest = new CatalogItemUpdateRequest
            {
                id = int.Parse(table.Rows[0]["Id"]),
                catalogBrandId = int.Parse(table.Rows[0]["catalogBrandId"]),
                catalogTypeId = int.Parse(table.Rows[0]["catalogTypeId"]),
                description = table.Rows[0]["description"],
                name = table.Rows[0]["name"],
                pictureUri = table.Rows[0]["pictureUri"],
                pictureBase64 = table.Rows[0]["pictureBase64"],
                pictureName = table.Rows[0]["pictureName"],
                price = decimal.Parse(table.Rows[0]["price"])
            };
            response = test.testPutEnpoint(catalogItemRequest);

            _scenarioContext.Add("tableval", table);


        }

        [Then(@"the response statusCode should equal  (.*)")]
        public void ThenTheResponseStatusCodeShouldEqual(int p0)
        {
            try
            {
                Assert.AreEqual((int)response.StatusCode, p0);
            }
            catch (Exception e)
            {
                Assert.Fail();
                Console.WriteLine("Message " + e.ToString());
            }
        }

        [Then(@"the response should contain the updated catalog item details")]
        public void ThenTheResponseShouldContainTheUpdatedCatalogItemDetails()
        {
            var tableValues = _scenarioContext.Get<Table>("tableval");



            test.IsWellUpdated(response ,tableValues);
        }
    }
}
